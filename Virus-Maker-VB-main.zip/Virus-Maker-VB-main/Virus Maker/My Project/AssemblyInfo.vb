﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Le informazioni generali relative a un assembly sono controllate dal seguente 
' insieme di attributi. Per modificare le informazioni associate a un assembly
' è necessario modificare i valori di questi attributi.

' Controllare i valori degli attributi dell'assembly

<Assembly: AssemblyTitle("Virus Maker")> 
<Assembly: AssemblyDescription("Virus Maker")> 
<Assembly: AssemblyCompany("BlackHost")> 
<Assembly: AssemblyProduct("Virus Maker")> 
<Assembly: AssemblyCopyright("Copyright © BlackHost")> 
<Assembly: AssemblyTrademark("BlackHost")> 

<Assembly: ComVisible(False)>

'Se il progetto viene esposto a COM, il GUID seguente verrà utilizzato come ID della libreria dei tipi
<Assembly: Guid("709126fe-a802-43a8-a9af-5d594c70d54f")> 

' Le informazioni sulla versione di un assembly sono costituite dai seguenti quattro valori:
'
'      Numero di versione principale
'      Numero di versione secondario 
'      Numero build
'      Revisione
'
' È possibile specificare tutti i valori oppure impostare valori predefiniti per i numeri relativi alla revisione e alla build 
' utilizzando l'asterisco (*) come descritto di seguito:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.0.0.0")> 
<Assembly: AssemblyFileVersion("0.0.0.0")> 
