# Virus Maker VB
From BlackHost, reuploaded for knowledge  
![screenshot](https://github.com/LotusTrojan/Virus-Maker-VB/assets/151651076/ccfd819c-13d0-42e0-872c-6cc700439a36)
