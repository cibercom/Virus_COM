# JavaScript-Based-DDOS
Hey so this site will basically send an HTTP GET Flood against the website of your choice. Just make sure to copy this repository and change the site in javascript to that of your choice! Try choosing a file in the site that has a lot space so that it does maximum damage. Also this is not a DDOS attack unless you share the link with a lot of people and they all get on it. If you have any questions or suggestions feel free to tell me and I will gladly respond. Either put it in Issues or shoot me an email!

Please subscribe to my YouTube, it would mean a lot

(C)2017 ninja25538 No Rights Reserved
